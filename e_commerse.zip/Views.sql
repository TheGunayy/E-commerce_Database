
create view product_detail_vw as
select 
 prd.product_detail_id,
 prd.product_id,
 pr.product_name,
 prd.measur_id,
 msr.measur_name,
 prd.color_id,
 clr.color_name,
 prd.description,
 prd.image_url,
 prd.price,
 pr.product_gategory_id,
 prc.category_name,
 pr.brand_id,
 br.brand_name

from 
product_detail prd
left join products pr on pr.product_id=prd.product_id
left join colors clr on prd.color_id=clr.color_id
left join measur msr on msr.measur_id=prd.measur_id
left join product_categories prc on pr.product_gategory_id=prc.category_id
left join brands br on pr.brand_id=br.brand_id
where 
prd.row_status=1;

select * from product_detail_vw ;


create view measur_vw as
select msr.measur_id,msr.measur_name,measur_value,msrt.measur_type_name from measur msr left join measur_types msrt on msr.measur_type_id=msrt.measur_type_id;

select * from measur_vw;

create view store_products_vw as
select 
	sp.store_product_id,
	sp.store_id,
	strs.store_name,
	ps.product_detail_id,
	prdvw.product_name,
	sp.quantity as store_quantity,
	ps.product_stock_id,
	ps.stock_id,
	ps.quantity as stock_quantity,
	stck.stock_name

from 
	store_products sp 
inner join product_stock ps on sp.product_stock_id=ps.product_stock_id
inner join stores strs on strs.store_id=sp.store_id
inner join stocks stck on stck.stock_id=ps.stock_id
inner join product_detail_vw prdvw on ps.product_detail_id=prdvw.product_detail_id
where 
sp.row_status=1

select * from store_products_vw


