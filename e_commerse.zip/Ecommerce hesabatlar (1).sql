﻿use ECommerce
--Tarix araliqinda en cox satilan mallar
select 

 --ordet.order_detail_id,
 --ordet.order_id,
 prod.product_name,
 sum(ordet.quantity) sifaris_sayi
 --ordet.quantity
 --ord.order_date

from order_detail ordet 
inner join orders ord on ordet.order_id=ord.order_id and ord.row_status=1
inner join store_products sp on ordet.store_product_id=sp.store_product_id
inner join product_stock  ps on sp.product_stock_id=ps.product_stock_id
inner join product_detail pdet on ps.product_detail_id=pdet.product_detail_id
inner join products prod on pdet.product_id=prod.product_id
where 
ord.order_date between '2024-12-01' and '2024-12-30'
group by product_name
order by  sum(ordet.quantity) desc,prod.product_name;

--Tarix araliqinda satilmayan mallar
with satislar as (
			select ordet.store_product_id,ord.order_date from order_detail ordet inner join orders ord on ordet.order_id=ord.order_id and ord.row_status=1 
)
select * from 
store_products_vw sp
where not exists (select 1 from satislar where sp.store_product_id=satislar.store_product_id and order_date between '2024-12-01' and '2024-12-30')
;
--Tarix araliqinda magazalarin satisi

select sp.store_id,sp.store_name,sum(ord.total_amount) total_satis from store_products_vw sp
inner join order_detail ordet on sp.store_product_id=ordet.store_product_id
inner join orders ord on ordet.order_id=ord.order_id
group by sp.store_id,sp.store_name



-- məhsulların stok vəziyyəti
	SELECT 
    p.product_name AS ProductName,
    ps.quantity AS StockQuantity,
    s.stock_name AS StockName,
    c.color_name AS Color,
    pd.price AS UnitPrice
FROM 
    products p
INNER JOIN 
    product_detail pd ON p.product_id = pd.product_id
INNER JOIN 
    product_stock ps ON pd.product_detail_id = ps.product_detail_id
INNER JOIN 
    stocks s ON ps.stock_id = s.stock_id
LEFT JOIN 
    colors c ON pd.color_id = c.color_id
WHERE 
    p.row_status = 1 AND ps.quantity > 0;


--şəhərlərə görə müştəri bölgüsü

	SELECT 
    ci.city_name AS CityName,
    COUNT(c.customer_id) AS TotalCustomers
FROM 
    customers c
INNER JOIN 
    delivery_addresses da ON c.customer_id = da.customer_id
INNER JOIN 
    cities ci ON da.city_id = ci.city_id
WHERE 
    c.row_status = 1
GROUP BY 
    ci.city_name
ORDER BY 
    TotalCustomers DESC;

--Məhsul Kategoriyalarına Görə Satış Performansı
	SELECT 
    pc.category_name AS CategoryName,
    SUM(od.total_price) AS TotalRevenue,
    SUM(od.quantity) AS TotalUnitsSold
FROM 
    order_detail od
INNER JOIN 
    store_products sp ON od.store_product_id = sp.store_product_id
INNER JOIN 
    products p ON sp.product_stock_id = p.product_id
INNER JOIN 
    product_categories pc ON p.product_gategory_id = pc.category_id
GROUP BY 
    pc.category_name
ORDER BY 
    TotalRevenue DESC;





