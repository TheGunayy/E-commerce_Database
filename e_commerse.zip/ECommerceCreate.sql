--create database ECommerce;
create database ECommerce
use ECommerce
create table personal_types
(
 type_id		int primary key identity(1,1),
 type_name		nvarchar(20) unique not null,
 insert_date	datetime default getdate(),
 update_date	datetime,
 row_status		bit
);

create table employees
(
 employee_id		int primary key identity(1,1),
 personal_type_id	int not null,
 name				nvarchar(50) not null,
 surname			nvarchar(50),
 email				varchar(100)  unique not null,
 phone_number		nvarchar(15)  unique,
 gender				varchar(2) not null,
 birthday			datetime not null,
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit,

 constraint chk_emplooyee_age check(datediff(year,birthday,GETDATE())>=18),
 constraint fk_emplooyees_type_id foreign key(personal_type_id) references personal_types(type_id)
);

CREATE INDEX idx_employees_personal_type_id ON employees(personal_type_id);
CREATE INDEX idx_employees_email ON employees(email);
CREATE INDEX idx_employees_phone_number ON employees(phone_number);


create table product_categories
(
 category_id		int primary key identity(1,1),
 category_name		nvarchar(50) unique not null,
 parent_category_id int,
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit
);

create table colors
(
 color_id			int primary key identity(1,1),
 color_name			nvarchar(50) unique not null,
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit
);
create table measur_types
(
 measur_type_id			int primary key identity(1,1),
 measur_type_name		nvarchar(50) not null,
 description			nvarchar(100),
 insert_date			datetime default getdate(),
 update_date			datetime,
 row_status				bit
);

create table measur
(
 measur_id				int primary key identity(1,1),
 measur_name			nvarchar(50) not null,
 measur_value			decimal(10,2) not null,
 measur_type_id			int not null,
 description			nvarchar(100),
 insert_date			datetime default getdate(),
 update_date			datetime,
 row_status				bit
 constraint fk_mesaur_measur_types foreign key(measur_type_id) references measur_types(measur_type_id)
); 

create table brands (
 brand_id			int primary key identity(1,1),
 brand_name			nvarchar(50) unique not null,
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit
);

create table products
(
 product_id			 int primary key identity(1,1),
 product_name		 nvarchar(100) unique not null,
 product_gategory_id int not null,
 brand_id			 int,
 insert_date		 datetime default getdate(),
 update_date		 datetime,
 row_status			 bit,
 
 constraint fk_product_category foreign key(product_gategory_id) references product_categories(category_id),
 constraint fk_product_brand foreign key(brand_id) references brands(brand_id)
);

CREATE INDEX idx_products_category_id ON products(product_gategory_id);
CREATE INDEX idx_products_brand_id ON products(brand_id);


create table product_detail
(
 product_detail_id	 int primary key identity(1,1),
 product_id			 int not null,
 measur_id		     int not null,
 price				 decimal(10,2) not null,
 color_id			 int not null,
 description		 nvarchar(200),
 image_url			 nvarchar(500),
 insert_date		 datetime default getdate(),
 update_date		 datetime,
 row_status			 bit,
 
 constraint fk_product_detail_product foreign key(product_id) references products(product_id) on delete cascade,
 constraint fk_product_detail_measur foreign key(measur_id) references measur(measur_id),
 constraint fk_product_detail_color foreign key(color_id) references colors(color_id),
 constraint chk_price check(price>0)
);

CREATE INDEX idx_product_detail_product_id ON product_detail(product_id);
CREATE INDEX idx_product_detail_measur_id ON product_detail(measur_id);
CREATE INDEX idx_product_detail_color_id ON product_detail(color_id);


create table stocks
(
 stock_id			int primary key identity(1,1),
 stock_name			nvarchar(50) unique not null,
 stock_manager_id	int not null,
 location           nvarchar(255),
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit

 constraint fk_stocks_stock_manager_id foreign key(stock_manager_id) references employees(employee_id)
);

create table product_stock
(
 product_stock_id	int primary key identity(1,1),
 stock_id			int not null,
 product_detail_id  int not null,
 quantity			int not null,
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit,
 
 constraint chk_product_stock_quantity check(quantity>0),
 constraint fk_product_stock_stocks foreign key(stock_id) references stocks(stock_id) on delete cascade,
 constraint fk_product_stock_product_detail foreign key(product_detail_id) references product_detail(product_detail_id) on delete cascade,
);

CREATE INDEX idx_product_stock_stock_id ON product_stock(stock_id);
CREATE INDEX idx_product_stock_product_detail_id ON product_stock(product_detail_id);


create table stores
(
 store_id			int primary key identity(1,1),
 store_name			nvarchar(50) unique not null,
 store_manager_id   int not null,
 delivery			int,
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit,
 
 constraint fk_stores_manager_id foreign key(store_manager_id) references employees(employee_id)
);

create table store_employees
(
 store_emp_id       int primary key identity(1,1),
 store_id			int ,
 employee_id		int ,
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit,
 
 constraint fk_stores_employees_employee_id foreign key(employee_id) references employees(employee_id),
 constraint fk_stores_employees_store_id foreign key(store_id) references stores(store_id)
);


create table store_products
(
 store_product_id	int primary key identity(1,1),
 store_id			int not null,
 product_stock_id   int not null,
 quantity			int not null,
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit,

 constraint fk_store_products_store_id foreign key(store_id) references stores(store_id),
 CONSTRAINT fk_store_products_product_stock_id foreign key(product_stock_id) references product_stock(product_stock_id),
 constraint chk_quantity check(quantity>0)
);

CREATE INDEX idx_store_products_store_id ON store_products(store_id);
CREATE INDEX idx_store_products_product_stock_id ON store_products(product_stock_id);


create table customers 
(
 customer_id	int primary key identity(1,1),
 name			nvarchar(50) not null,
 surname		nvarchar(50),
 email			varchar(100)  unique not null,
 phone_number	nvarchar(15)  unique,
 gender			varchar(2) not null,
 birthday		datetime not null,
 insert_date	datetime default getdate(),
 update_date	datetime,
 row_status		bit,
 
 constraint chk_customer_age check(datediff(year,birthday,GETDATE())>=18)
);
create table cities
(
	city_id		int primary key identity(1,1),
	city_name	nvarchar(50) unique not null,
	insert_date	datetime default getdate(),
	update_date	datetime,
	row_status	bit
)

create table delivery_addresses
(
	adres_id		int primary key identity(1,1),
	customer_id		int not null,
	city_id			int,
	adres_line_1	nvarchar(500) not null,
	adres_line_2	nvarchar(500),
	postal_code		nvarchar(20),
	phone_number	nvarchar(20) not null,
	is_primary		bit,
	insert_date		datetime default getdate(),
	update_date		datetime,
	row_status		bit

	constraint fk_delivery_adresses_city_id foreign key (city_id) references cities(city_id),
	constraint fk_delivery_adresses_customer_id foreign key (customer_id) references customers(customer_id)
);

CREATE INDEX idx_delivery_addresses_customer_id ON delivery_addresses(customer_id);
CREATE INDEX idx_delivery_addresses_city_id ON delivery_addresses(city_id);


create table order_statuses
(
 order_status_id    int primary key identity(1,1),
 order_status	    nvarchar(20),
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit
)
create table shopping_cart
(
 cart_id			int primary key identity(1,1),
 customer_id		int not null,
 is_active          bit,                
 insert_date        datetime default getdate(), 
 update_date        datetime,                      
 row_status         bit ,   

 constraint fk_shopping_cart_customer_id foreign key(customer_id) references customers(customer_id)
)

create table cart_items
(
 cart_item_id		int primary key identity(1,1),
 store_product_id   int not null,                 
 quantity           int not null,
 cart_id            int not null,
 item_price         decimal(10, 2) not null,       
 added_date         datetime default getdate(),                 
 insert_date        datetime default getdate(), 
 update_date        datetime,                      
 row_status         bit,      

 constraint chk_shopping_cart_quantity check(quantity>0),
 constraint fk_cart_items_store_product_id foreign key(store_product_id) references store_products(store_product_id),
 constraint fk_cart_items_cart_id foreign key(cart_id) references shopping_cart(cart_id)
)
CREATE INDEX idx_cart_items_store_product_id ON cart_items(store_product_id);

 create table payment_methods
(
    payment_method_id   int primary key identity(1,1),
    method_name         nvarchar(50) unique not null,
    description         nvarchar(100),
    insert_date         datetime default getdate(),
    update_date         datetime,
    row_status          bit
);

create table orders
(
 order_id			int primary key identity(1,1),
 cart_id			int,
 customer_id		int not null,
 order_date			datetime,
 order_status_id	int,
 payment_method_id   int not null,
 total_amount		decimal(10,2) not null,
 adres_id			int not null,	
 insert_date		datetime default getdate(),
 update_date		datetime,
 row_status			bit,

 constraint fk_orders_customer_id foreign key(customer_id) references customers(customer_id) on delete cascade,
 constraint fk_orders_adres_id foreign key (adres_id) references delivery_addresses(adres_id),
 constraint fk_orders_order_status_id foreign key (order_status_id) references order_statuses(order_status_id),
 constraint fk_orders_method_id foreign key(payment_method_id) references payment_methods(payment_method_id),  
 constraint chk_total_amount check(total_amount>0)
 );

CREATE INDEX idx_orders_customer_id ON orders(customer_id);
CREATE INDEX idx_orders_order_status_id ON orders(order_status_id);
CREATE INDEX idx_orders_adres_id ON orders(adres_id);


 create table order_detail
 (
  order_detail_id  int primary key identity(1,1),
  order_id		   int not null,
  store_product_id int not null,
  quantity         int not null,
  order_price	   decimal(10,2),
  total_price      as (quantity * order_price) persisted, 
  insert_date	   datetime default getdate(),
  update_date	   datetime,
  row_status	   bit

  constraint fk_order_detail_order_id foreign key(order_id) references orders(order_id) on delete cascade,
  constraint fk_order_detail_str_prod_id foreign key(store_product_id) references store_products(store_product_id)
 );
 
 CREATE INDEX idx_order_detail_order_id ON order_detail(order_id);
 CREATE INDEX idx_order_detail_store_product_id ON order_detail(store_product_id);

 create table payment_status
(
    payment_status_id   int primary key identity(1,1),
    payment_status_name nvarchar(50) unique not null,
    description         nvarchar(100),
    insert_date         datetime default getdate(),
    update_date         datetime,
    row_status          bit
);


create table payments
(
    payment_id          int primary key identity(1,1),
    order_id            int not null,                        
    payment_date        datetime default getdate(), 
    amount_paid         decimal(10,2) not null,   
    payment_status_id   int not null,    
    transaction_code    nvarchar(100),            
    insert_date         datetime default getdate(),
    update_date         datetime,
    row_status          bit,

   
    constraint fk_payments_order_id foreign key(order_id) references orders(order_id) on delete cascade,
	constraint fk_payments_payment_status_id foreign key(payment_status_id) references payment_status(payment_status_id),    
    constraint chk_amount_paid check(amount_paid > 0)
);


CREATE INDEX idx_payments_order_id ON payments(order_id);







